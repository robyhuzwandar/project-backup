import React from 'react';
export const Const = {
	path:'/',
	api:'http://dev.nostratech.com:10093/'
};

