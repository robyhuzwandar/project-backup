import React, { Component } from 'react';
import Routes from './controllers/Routes';
class App extends React.Component{
  render() {
	    return (
		   <Routes />
	    );
	}
}
module.exports = App;