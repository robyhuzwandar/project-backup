import React from 'react';
class Footer extends React.Component{
	render(){
		return(<div className="col-lg-12">
					<div className="col-lg-12 text-center footer">
						<p>Copyright © 2018-2023 React DevWan <br/>All rights reserved</p>
					</div>
			   </div>
		) 
	}
}
module.exports=Footer;