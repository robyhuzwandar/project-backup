@extends('admin')
@section('content')
    <div class="box box-success">
        <div class="box-header">
            <h3 class="box-title">Dashboard</h3>
        </div>
        <!-- /.box-header -->
        <div class="box-body">
              
        </div>
        <!-- /.box-body -->
    </div>
@endsection