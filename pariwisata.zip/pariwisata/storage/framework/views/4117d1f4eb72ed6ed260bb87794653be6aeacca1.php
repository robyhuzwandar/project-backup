<?php $__env->startSection('content'); ?>
    <!-- Main content -->
    <div class="box box-success">
        <div class="box-header">
            <h3 class="box-title">Tambahkan Hotel</h3>
        </div>
        <div class="box-body">
            <div class="row">
                <div class="col-md-6">
                    <?php echo $__env->make('template.alert', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                    <form action="<?php echo e(route('hotel.store')); ?>" method="post" enctype="multipart/form-data"
                          id="contactForm">
                        <?php echo e(csrf_field()); ?>

                        <div class="form-group <?php echo e($errors->has('name') ? ' has-error' : ''); ?>">
                            <label>Name</label>
                            <input value="<?php echo e(old('name')); ?>" type="text" class="form-control" name="name">
                            <?php if($errors->has('name')): ?>
                                <span class="help-block"><strong><?php echo e($errors->first('name')); ?></strong></span>
                            <?php endif; ?>
                        </div>

                        <div class="form-group <?php echo e($errors->has('phone') ? ' has-error' : ''); ?>">
                            <label>Phone</label>
                            <input value="<?php echo e(old('phone')); ?>" type="text" class="form-control" name="phone">
                            <?php if($errors->has('phone')): ?>
                                <span class="help-block"><strong><?php echo e($errors->first('phone')); ?></strong></span>
                            <?php endif; ?>
                        </div>

                        <div class="form-group <?php echo e($errors->has('fax') ? ' has-error' : ''); ?>">
                            <label>Fax</label>
                            <input value="<?php echo e(old('fax')); ?>" type="number" class="form-control" name="fax">
                            <?php if($errors->has('fax')): ?>
                                <span class="help-block"><strong><?php echo e($errors->first('fax')); ?></strong></span>
                            <?php endif; ?>
                        </div>

                        <div class="form-group  <?php echo e($errors->has('email') ? ' has-error' : ''); ?>">
                            <label>Email</label>
                            <input value="<?php echo e(old('email')); ?>" type="text" class="form-control" name="email">
                            <?php if($errors->has('email')): ?>
                                <span class="help-block"><strong><?php echo e($errors->first('email')); ?></strong></span>
                            <?php endif; ?>
                        </div>

                        <div class="form-group  <?php echo e($errors->has('npwp') ? ' has-error' : ''); ?>">
                            <label>Npwp</label>
                            <input value="<?php echo e(old('npwp')); ?>" type="number" class="form-control" name="npwp">
                            <?php if($errors->has('npwp')): ?>
                                <span class="help-block"><strong><?php echo e($errors->first('npwp')); ?></strong></span>
                            <?php endif; ?>
                        </div>
                        <button type="submit" class="btn btn-primary btn-flat" name="submit"><span
                                    class="glyphicon glyphicon-send"></span> Simpan
                        </button>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>