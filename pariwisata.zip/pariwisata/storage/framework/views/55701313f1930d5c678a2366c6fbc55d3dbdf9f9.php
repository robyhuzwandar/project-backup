<?php $__env->startSection('content'); ?>
    <div class="box box-success">
        <div class="box-header">
            <h3 class="box-title">Dashboard</h3>
        </div>
        <!-- /.box-header -->
        <div class="box-body">
              
        </div>
        <!-- /.box-body -->
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>